// content.js

function getPromptBox() {

    const selectors = [

        "#prompt-textarea",

        "textarea",

        "[contenteditable='true']"

    ];

    for (const selector of selectors) {

        const element = document.querySelector(selector);

        if (element)
            return element;

    }

    return null;

}

function createFloatingWidget() {

    if (document.getElementById("promptshield-widget"))
        return;

    const widget = document.createElement("div");

    widget.id = "promptshield-widget";

    widget.innerHTML = `

        <div id="ps-title">
            🛡 PromptShield AI
        </div>

        <div id="ps-score">
            AI Safety Score :
            <span id="ps-value">100</span>
        </div>

        <div id="ps-risk">
            Safe
        </div>

    `;

    widget.style.position = "fixed";
    widget.style.bottom = "20px";
    widget.style.right = "20px";

    widget.style.width = "240px";

    widget.style.padding = "15px";

    widget.style.background = "white";

    widget.style.borderRadius = "15px";

    widget.style.boxShadow = "0 0 15px rgba(0,0,0,.25)";

    widget.style.zIndex = "999999";

    widget.style.fontFamily = "Arial";

    document.body.appendChild(widget);

}

function updateWidget(score, risk) {

    const scoreElement = document.getElementById("ps-value");

    const riskElement = document.getElementById("ps-risk");

    if (!scoreElement)
        return;

    scoreElement.innerText = score;

    riskElement.innerText = risk;

    if (score >= 80)
        riskElement.style.color = "green";

    else if (score >= 50)
        riskElement.style.color = "orange";

    else
        riskElement.style.color = "red";

}

createFloatingWidget();

setInterval(() => {

    const box = getPromptBox();

    if (!box)
        return;

    const text = box.value || box.innerText;

    const findings = scanPrompt(text);

    const risk = calculateRisk(findings);

    updateWidget(risk.score, risk.risk);

}, 800);